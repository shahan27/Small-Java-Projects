import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

public class CowAttack extends Creature
{


    //ANIMATION
    private Animation animCow;

    //Attack Timer
    private long  attackCooldown = 800, attackTimer = attackCooldown;

    //Inventory
    private Inventory inventory;


    public CowAttack(Handler handler, float x, float y)
    {
        super(handler, x,y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
        bounds.x = 25;
        bounds.y = 20;
        bounds.width = 32;
        bounds.height = 32;
        health = 20;


        //Animation
        animCow = new Animation(500,Assets.cow_stand);

    }


    @Override
    public void tick()
    {
        //Animation
        animCow.tick();


        //movement
        getInput();
        move();

        //Attack


    }



    public void die()
    {
        System.out.println("You Killed A Cow");
    }


    private void getInput()
    {
        Random rand = new Random();
        int n = rand.nextInt(50);
        xMove = 0;
        yMove = 0;

        if(n == 1)
        {
            yMove = -5.5f;
        }
        if(n == 3)
        {
            yMove = 5.5f;
        }
        if(n == 6)
        {
            xMove = -5.5f;
        }
        if(n == 9)
        {
            xMove = 5.5f;
        }
    }


    @Override
    public void render(Graphics g)
    {

        String health = String.valueOf(getHealth());
        g.drawString("HP : " + health, (int)(x-handler.getGameCamera().getxOffset()), (int)(y-handler.getGameCamera().getyOffset()));
        g.drawImage(getCurrentAnimationFrame(), (int)(x - handler.getGameCamera().getxOffset()), (int)(y- handler.getGameCamera().getyOffset()), width, height, null);
    }




    private BufferedImage getCurrentAnimationFrame()
    {
        if(xMove < 0)
        {
            return animCow.getCurrentFrame();
        }
        else if (xMove > 0)
        {
            return animCow.getCurrentFrame();
        }
        else if (yMove < 0)
        {
            return animCow.getCurrentFrame();
        }
        else if(yMove > 0)
        {
            return animCow.getCurrentFrame();
        }
        else
        {
            return animCow.getCurrentFrame();
        }
    }
}
