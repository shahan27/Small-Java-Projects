public abstract class Herbivore extends Creature{

    private boolean danger = false;//

    public Herbivore(Handler handler, float x, float y, int width, int height) {
        super(handler, x, y, width, height);
    }

    public boolean isDangerous(){
        return danger;
    }

}
