import java.awt.image.BufferedImage;
import java.awt.Font;

public class Assets
{


    private static final int width = 32, height = 32;

    public static Font font28;



    public static BufferedImage nightFloor, grass, stone, tree, playerHurt, playerDead, rock, flint, base , playerTorch;
    public static BufferedImage wood;

    public static BufferedImage[] aligatorDown, bunnyDown, tigerDown;

    public static BufferedImage[] player_down, player_up, player_left, player_right, player_stand, cow_stand;

    public static BufferedImage[] btn_start;
    public static BufferedImage inventoryScreen;


    public static void init()
    {
        font28 = FontLoader.loadFont("res/fonts/slkscr.ttf", 28);


        SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/sheet.png"));
        SpriteSheet Agentsheets = new SpriteSheet(ImageLoader.loadImage("/textures/agentSheet.png"));
        SpriteSheet Cowsheets = new SpriteSheet(ImageLoader.loadImage("/textures/cow.png"));

        SpriteSheet tigerSheet = new SpriteSheet(ImageLoader.loadImage("/textures/tiger.png"));
        SpriteSheet bunnySheet = new SpriteSheet(ImageLoader.loadImage("/textures/bunny.png"));
        SpriteSheet alligatorSheet = new SpriteSheet(ImageLoader.loadImage("/textures/alligator.png"));

        inventoryScreen = ImageLoader.loadImage("textures/inventoryScreen.png");

        //player
        cow_stand = new BufferedImage[1];
        player_down = new BufferedImage[2];
        player_up = new BufferedImage[2];
        player_left = new BufferedImage[2];
        player_right = new BufferedImage[2];
        player_stand = new BufferedImage[2];
        tigerDown = new BufferedImage[1];
        aligatorDown = new BufferedImage[1];



        bunnyDown = new BufferedImage[1];

        bunnyDown[0] = bunnySheet.crop(123,0,68,60);
        tigerDown[0]= tigerSheet.crop(264,120,50,32);
        aligatorDown[0] = alligatorSheet.crop(40,0,65,75);




        //menu
        btn_start = new BufferedImage[2];

        cow_stand[0] = Cowsheets.crop(0,0,100,100);

        playerTorch = Agentsheets.crop(40,40, 25, 40);

        player_stand[0] = Agentsheets.crop(0,40, 25, 40);
        player_stand[1] = Agentsheets.crop(80,40, 25, 40);

        player_up[0] = Agentsheets.crop(0,160, 25, 38);
        player_up[1] = Agentsheets.crop(40,160, 25, 38);

        player_left[0] = Agentsheets.crop(240,120, 25, 40);
        player_left[1] = Agentsheets.crop(270,120, 25, 40);

        player_right[0] = Agentsheets.crop(0,80, 25, 40);
        player_right[1] = Agentsheets.crop(40,80, 23, 40);

        player_down[0] = Agentsheets.crop(240,160, 25, 40);
        player_down[1] = Agentsheets.crop(275,160, 23, 40);

        btn_start[0] = sheet.crop(width * 6, height * 4, width * 2, height);
        btn_start[1] = sheet.crop(width * 6, height * 5, width * 2, height);

        base = sheet.crop(width * 2,height, width, height);


        wood = sheet.crop(width,height, width, height);
        flint = sheet.crop(32, height * 2, width, height);



        //tigerLeft = tigerSheet.crop(95,120,50,32);
        //tigerRight = tigerSheet.crop(264,120,50,32);
        //tigerUp = tigerSheet.crop(0,120,50,32);

        //bunnyUp = bunnySheet.crop(54,0,38,60);    bunnySheet.crop(18,0,38,60)
        //bunnyRight = bunnySheet.crop(123,0,68,60);
        //bunnyLeft = bunnySheet.crop(191,0,68,60);


        nightFloor = sheet.crop(32,0, 32, 32);
        grass = sheet.crop(32 * 2,0, 32, 32);
        stone = sheet.crop(32 * 3,0, 32, 32);
        tree = sheet.crop(0,0, 32, 64);
        rock = sheet.crop(0, height * 2, width, height);

        playerHurt = Agentsheets.crop(0,200, 25, 40);
        playerDead = Agentsheets.crop(320,40, 25, 40);

    }

}
