public class Main
{
    public static void main(String[] args)
    {
        Game game = new Game("Artificial Life", 640, 450); // 640 450
        game.start();
    }
}
