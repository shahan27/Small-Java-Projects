import java.awt.*;
import java.security.PublicKey;

public class World
{
    private Handler handler;
    private int width, height;
    private int spawnX, spawnY;
    private int[][] tiles;


    //Entity
    private EntityManager entityManager;

    //Item
    private ItemManager itemManager;


    public World(Handler handler, String path)
    {
        this.handler = handler;
        entityManager = new EntityManager(handler, new Player(handler, 100,100));
        itemManager = new ItemManager(handler);

        //TEMP
        entityManager.addEntity(new Tree(handler, 200,250));
        entityManager.addEntity(new Rock(handler, 100,450));
        entityManager.addEntity(new Tree(handler, 200,350));
        entityManager.addEntity(new Rock(handler, 100,275));
        entityManager.addEntity(new Cow(handler, 100,150));
        entityManager.addEntity(new Flint(handler, 400,150));
        entityManager.addEntity(new Flint(handler, 550,150));

        entityManager.addEntity(new Tiger(handler, 500,550));
        entityManager.addEntity(new Tiger(handler, 500,850));
        entityManager.addEntity(new Bunny(handler, 750,950));
        entityManager.addEntity(new Bunny(handler, 250,350));
        entityManager.addEntity(new Alligator(handler, 600,600));
        entityManager.addEntity(new Alligator(handler, 750,350));


        entityManager.addEntity(new CowAttack(handler, 600,150));


        loadWorld(path);

        entityManager.getPlayer().setX(spawnX);
        entityManager.getPlayer().setY(spawnY);



    }

    public void tick()
    {
        itemManager.tick();
        entityManager.tick();

    }

    public void render(Graphics g)
    {
        int xStart = (int) Math.max(0, handler.getGameCamera().getxOffset()/Tile.TILEWIDTH );
        int xEnd = (int) Math.min(width, (handler.getGameCamera().getxOffset() + handler.getWidth()) / Tile.TILEWIDTH);
        int yStart = (int) Math.max(0, handler.getGameCamera().getyOffset()/Tile.TILEHEIGHT );
        int yEnd = (int) Math.min(height, (handler.getGameCamera().getyOffset() + handler.getHeight()) / Tile.TILEHEIGHT);



        for(int y = yStart; y < yEnd; y++)
        {
            for(int x = xStart; x < xEnd; x++)
            {
                getTile(x,y).render(g, (int) (x * Tile.TILEWIDTH - handler.getGameCamera().getxOffset()), (int)(y * Tile.TILEHEIGHT - handler.getGameCamera().getyOffset()));
            }
        }

        //Items
        itemManager.render(g);

        //Entities
        entityManager.render(g);
    }


    public Tile getTile(int x, int y)
    {
        if(x < 0 || y < 0 || x >= width || y >= height)
            return Tile.grassTile;


        Tile t = Tile.tiles[tiles[x][y]];
        if(t == null)
            return Tile.nightFloor;
        return t;
    }


    private void loadWorld(String path)
    {
        String file = Utils.loadFileAsString(path);
        String [] tokens = file.split("\\s+");
        width = Utils.parseInt(tokens[0]);
        height= Utils.parseInt(tokens[1]);
        spawnX = Utils.parseInt(tokens[2]);
        spawnY = Utils.parseInt(tokens[3]);

        tiles = new int[width][height];

        for(int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                tiles[x][y] = Utils.parseInt(tokens[(x+y * width) + 4]);
            }

        }


    }

    //getter


    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public ItemManager getItemManager() {
        return itemManager;
    }

    public void setItemManager(ItemManager itemManager) {
        this.itemManager = itemManager;
    }

    public EntityManager getEntityManager()
    {
        return entityManager;
    }

    //width and hieght of the world
    public int getWidth()
    {
        return width;
    }

    public int getHeight()
    {
        return height;
    }

}
