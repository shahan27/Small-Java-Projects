import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Tiger extends Carnivore
{


    //ANIMATION
    private Animation animTiger;

    //Attack Timer
    private long lastAttackTimer, attackCooldown = 800, attackTimer = attackCooldown;








    public Tiger(Handler handler, float x, float y)
    {
        super(handler, x,y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
        bounds.x = 25;
        bounds.y = 20;
        bounds.width = 32;
        bounds.height = 32;
        health = 20;


        //Animation
        animTiger= new Animation(500,Assets.tigerDown);

    }


    @Override
    public void tick()
    {
        //Animation
        animTiger.tick();


        //movement
        getInput();
        move();

        //Attack
     checkAttacks();

    }
    public void checkAttacks()
    {
        attackTimer+=System.currentTimeMillis() - lastAttackTimer;
        lastAttackTimer = System.currentTimeMillis();
        if(attackTimer < attackCooldown)
            return;

        Rectangle cb = getCollisionBounds(0,0);
        Rectangle ar = new Rectangle();
        int arSize = 20;
        ar.width = arSize;
        ar.height = arSize;

        if(handler.getKeyManager().aUp)
        {
            ar.x = cb.x + cb.width /2 - arSize/2;
            ar.y = cb.y + cb.height;
        }
        else if(handler.getKeyManager().aDown)
        {
            ar.x = cb.x + cb.width /2 - arSize/2;
            ar.y = cb.y - arSize;
        }
        else if(handler.getKeyManager().aLeft)
        {


            ar.x = cb.x + cb.width;
            ar.y = cb.y + cb.height/2 - arSize /2;
        }
        else if(handler.getKeyManager().aRight)
        {

            ar.x = cb.x - arSize;
            ar.y = cb.y + cb.height/2 - arSize /2;
        }
        else
        {
            return;
        }
        attackTimer = 0;

        for (Entity e: handler.getWorld().getEntityManager().getEntities())
        {
            if(e.equals(this))
            {
                continue;
            }
            if(e.getCollisionBounds(0,0).intersects(ar))
            {
                e.hurt(1);
                return;
            }
        }

    }




    public void die()
    {
        System.out.println("You Killed A Tiger");
    }


    private void getInput()
    {
        Random rand = new Random();
        int n = rand.nextInt(50);
        xMove = 0;
        yMove = 0;


        if(n == 1)
        {
            yMove = -5.5f;
        }
        if(n == 3)
        {
            yMove = 5.5f;
        }
        if(n == 6)
        {
            xMove = -5.5f;
        }
        if(n == 9)
        {
            xMove = 5.5f;
        }
    }


    @Override
    public void render(Graphics g)
    {

        //System.out.println(EntityManager.getPlayer().getY());
        String health = String.valueOf(getHealth());
        g.drawString("HP : " + health, (int)(x-handler.getGameCamera().getxOffset()), (int)(y-handler.getGameCamera().getyOffset()));
        g.drawImage(getCurrentAnimationFrame(), (int)(x - handler.getGameCamera().getxOffset()), (int)(y- handler.getGameCamera().getyOffset()), width, height, null);
    }



    private BufferedImage getCurrentAnimationFrame()
    {
        if(xMove < 0)
        {
            return animTiger.getCurrentFrame();
        }
        else if (xMove > 0)
        {
            return animTiger.getCurrentFrame();
        }
        else if (yMove < 0)
        {
            return animTiger.getCurrentFrame();
        }
        else if(yMove > 0)
        {
            return animTiger.getCurrentFrame();
        }
        else
        {
            return animTiger.getCurrentFrame();
        }
    }
}


