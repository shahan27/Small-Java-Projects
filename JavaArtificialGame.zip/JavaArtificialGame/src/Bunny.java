import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Bunny extends Herbivore
{


    //ANIMATION
    private Animation animBunny;

    //Attack Timer
    private long  attackCooldown = 800, attackTimer = attackCooldown;




    public Bunny(Handler handler, float x, float y)
    {
        super(handler, x,y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
        bounds.x = 25;
        bounds.y = 20;
        bounds.width = 32;
        bounds.height = 32;
        health = 5;


        //Animation
        animBunny = new Animation(500,Assets.bunnyDown);

    }


    @Override
    public void tick()
    {
        //Animation
        animBunny.tick();


        //movement
        getInput();
        move();

        //Attack


    }



    public void die()
    {
        System.out.println("You Killed A Bunny");
    }


    private void getInput()
    {
        Random rand = new Random();
        int n = rand.nextInt(50);
        xMove = 0;
        yMove = 0;

        if(n == 1)
        {
            yMove = -5.5f;
        }
        if(n == 3)
        {
            yMove = 5.5f;
        }
        if(n == 6)
        {
            xMove = -5.5f;
        }
        if(n == 9)
        {
            xMove = 5.5f;
        }
    }



    @Override
    public void render(Graphics g)
    {

        String health = String.valueOf(getHealth());
        g.drawString("HP : " + health, (int)(x-handler.getGameCamera().getxOffset()), (int)(y-handler.getGameCamera().getyOffset()));
        g.drawImage(getCurrentAnimationFrame(), (int)(x - handler.getGameCamera().getxOffset()), (int)(y- handler.getGameCamera().getyOffset()), width, height, null);
    }



    private BufferedImage getCurrentAnimationFrame()
    {
        if(xMove < 0)
        {
            return animBunny.getCurrentFrame();
        }
        else if (xMove > 0)
        {
            return animBunny.getCurrentFrame();
        }
        else if (yMove < 0)
        {
            return animBunny.getCurrentFrame();
        }
        else if(yMove > 0)
        {
            return animBunny.getCurrentFrame();
        }
        else
        {
            return animBunny.getCurrentFrame();
        }
    }
}


