public class NightFloor extends Tile
{

    public NightFloor(int id)
    {
        super(Assets.nightFloor, id);
    }


}
